# HR transaction policy rules (synthetic)

- **R01 · Pay change approval limit.** Pay changes up to AED 5,000 a month need an approver of grade 8 or above; up to AED 20,000, grade 11 or above; above AED 20,000, grade 13 or above.
- **R02 · Allowance approval limit.** Allowances up to AED 3,000 need grade 7 or above; up to AED 10,000, grade 10 or above; above AED 10,000, grade 12 or above.
- **R03 · Hiring approval limit.** Hires with a monthly salary up to AED 25,000 need grade 10 or above; above AED 25,000, grade 13 or above.
- **R04 · Two approvals required.** Hires, exits and pay changes above AED 10,000 need two different approvers.
- **R05 · Requester cannot approve.** The person who raises a transaction must not approve it.
- **R06 · No action on own record.** Employees must not raise or approve transactions on their own record.
- **R07 · Line manager approval.** Transfers and leave must be approved by the employee's line manager.
- **R08 · Required documents.** Hires need an offer letter, passport and medical; pay changes a justification; allowances an eligibility form; transfers a transfer form; exits a resignation letter and clearance form.
- **R09 · Backdating limit.** A transaction must not take effect more than 30 days before it was requested.
- **R10 · Future-dating limit.** A transaction must not take effect more than 90 days after it was requested.
- **R11 · Approved before effective date.** Hires, pay changes, allowances and transfers must be fully approved on or before the effective date.
- **R12 · No changes after exit.** No transaction other than the exit itself may take effect after an employee's exit date.
- **R13 · No changes before hire.** No transaction other than the hire may take effect before an employee's hire date.
- **R14 · Duplicate transaction.** The same transaction must not be processed twice for the same employee, type, amount and effective date.
- **R15 · Split to avoid approval limit.** Changes of the same type for the same employee within 30 days are added together for approval limits.
- **R16 · Allowance within grade cap.** Monthly allowances must not exceed AED 2,000 for grades 1 to 5, AED 5,000 for grades 6 to 9, AED 10,000 for grades 10 to 12 and AED 20,000 for grade 13 and above.
- **R17 · Annual leave entitlement.** An employee may take at most 30 days of leave in a calendar year.
- **R18 · Approver senior to employee.** Pay changes must be approved by someone of a higher grade than the employee.
